
document.addEventListener('DOMContentLoaded', function () {

    const images = [
        "images/image1.jpeg",
        "images/image2.jpeg",
        "images/image3.jpeg",
        "images/image4.jpeg"
    ];

    let currentIndex = 0;

    const mainImage = document.getElementById('mainImage');
    const thumbnails = document.querySelectorAll('.thumb');
    const prevBtn = document.getElementById('prevBtn');
    const nextBtn = document.getElementById('nextBtn');


    function showImage(index) {

        currentIndex = index;

        mainImage.src = images[currentIndex];

        thumbnails.forEach(function (thumb) {
            thumb.classList.remove('active');
        });

        thumbnails[currentIndex].classList.add('active');
    }


    function nextImage() {

        currentIndex++;

        if (currentIndex >= images.length) {
            currentIndex = 0;
        }

        showImage(currentIndex);
    }


    function prevImage() {

        currentIndex--;

        if (currentIndex < 0) {
            currentIndex = images.length - 1;
        }

        showImage(currentIndex);
    }


    nextBtn.addEventListener('click', nextImage);

    prevBtn.addEventListener('click', prevImage);


    thumbnails.forEach(function (thumb) {

        thumb.addEventListener('click', function () {

            const index = Number(thumb.dataset.index);

            showImage(index);

        });

    });


    setInterval(nextImage, 3000);


    const form = document.getElementById('registerForm');

    form.addEventListener('submit', function (event) {

        event.preventDefault();

        const firstName = form.querySelector('input[name="firstName"]');
        const lastName = form.querySelector('input[name="lastName"]');
        const email = form.querySelector('input[name="email"]');
        const password = form.querySelector('input[name="password"]');
        const confirmPassword = form.querySelector('input[name="rPassword"]');
        const city = form.querySelector('select[name="city"]');


        if (firstName.value.trim() === '') {
            alert('Please enter your First Name.');
            firstName.classList.add('error');
            firstName.focus();
            return;
        }


        if (lastName.value.trim() === '') {
            alert('Please enter your Last Name.');
            lastName.classList.add('error');
            lastName.focus();
            return;
        }


        if (email.value.trim() === '') {
            alert('Please enter your Email.');
            email.classList.add('error');
            email.focus();
            return;
        }


        if (password.value === '') {
            alert('Please enter your Password.');
            password.classList.add('error');
            password.focus();
            return;
        }


        if (confirmPassword.value === '') {
            alert('Please confirm your Password.');
            confirmPassword.classList.add('error');
            confirmPassword.focus();
            return;
        }


        const gender = form.querySelector(
            'input[name="gender"]:checked'
        );

        if (!gender) {
            alert('Please select your Gender.');
            return;
        }


        if (city.value === '') {
            alert('Please select your City.');
            city.classList.add('error');
            city.focus();
            return;
        }


        const courses = form.querySelectorAll(
            'input[name="courses[]"]:checked'
        );

        if (courses.length === 0) {
            alert('Please select at least one Course.');
            return;
        }


        if (password.value.length < 6) {
            alert('Password must be at least 6 characters long.');
            password.classList.add('error');
            password.focus();
            return;
        }


        if (password.value !== confirmPassword.value) {
            alert('Passwords do not match.');
            confirmPassword.classList.add('error');
            confirmPassword.focus();
            return;
        }


        alert(
            'Form submitted successfully!\n' +
            'Name: ' + firstName.value + ' ' + lastName.value + '\n' +
            'Email: ' + email.value + '\n' +
            'Gender: ' + gender.value + '\n' +
            'City: ' + city.value
        );

        form.reset();

    });


    form.querySelectorAll('input, select').forEach(function (field) {

        field.addEventListener('input', function () {
            field.classList.remove('error');
        });

        field.addEventListener('change', function () {
            field.classList.remove('error');
        });

    });

});

